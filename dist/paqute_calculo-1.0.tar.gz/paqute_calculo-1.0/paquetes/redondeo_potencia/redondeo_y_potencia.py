def potencia(base, exponente):
  print(f'La potencia del número es: {base ** exponente}')

def redondear(numero):
  print(f'El resultado de la suma es: {round(numero)}')
