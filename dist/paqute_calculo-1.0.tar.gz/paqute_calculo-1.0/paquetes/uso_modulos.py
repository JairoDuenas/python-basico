from basicos.operaciones_basicas import dividir, sumar
from redondeo_potencia.redondeo_y_potencia import potencia, redondear

dividir(4, 2)
sumar(10, 5)
potencia(2, 3)
redondear(4.8)