from setuptools import setup

setup(
  name='paqute_calculo',
  version='1.0',
  description='Paquete de redondeo y potencia',
  author='Jairo',
  author_email='jairo@gmail.com',
  url='www.jairodv.com',
  packages=['paquetes', 'paquetes.redondeo_potencia']
)